﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/* 
Name: MechLoad
Purpose: Handles Loading of Mech into Scenes
Version and date: 1.0 : 5/31/19 
Author(s): Tristan H.
Dependencies: None
*/

public class MechLoad : MonoBehaviour
{
    public GameObject MachineR;
    public GameObject MachineL;
    public GameObject LaserR;
    public GameObject LaserL;
    void Awake()
    {
        int weaponRight = PlayerInfo.WeaponRight;
        int weaponLeft = PlayerInfo.WeaponLeft;
        if(weaponRight == 0)
        {
            MachineR.SetActive(true);
            Debug.Log("Right Machine Gun Active");
        }
        else if(weaponRight == 1)
        {
            LaserR.SetActive(true);
            Debug.Log("Right Laser Gun Active");
        }
        if (weaponLeft == 0)
        {
            MachineL.SetActive(true);
            Debug.Log("Left Machine Gun Active");
        }
        else if (weaponLeft == 1)
        {
            LaserL.SetActive(true);
            Debug.Log("Left Laser Gun Active");
        }
    }
}
