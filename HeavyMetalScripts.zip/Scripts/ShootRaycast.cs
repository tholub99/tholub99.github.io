﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Valve.VR;

/* 
Name: ShootRaycast
Purpose: MachineGun Firing Method
Version and date: 1.0 : 5/9/19 
Author(s): Tristan H., Andrew S.
Dependencies: None
*/

public class ShootRaycast : MonoBehaviour
{
    public const float rotAccel = 5400.0f; //deg / frame^2
    public const float fireVel = 1620.0f; //deg / frame

    //Gun constants
    public float range = 100f; //HitScan Range
    public float damage = 5.0f;
    public float impctf = 30.0f;

    //Prefab Variables
    public GameObject sparkPrefab;
    public LineRenderer LinePrefab;

    //GameObjects
    public Transform barrelObj;
    public Transform bulletspawn;

    public SteamVR_Input_Sources hand; //Hand Input

    //Rotation variables
    private float rotVel = 0.0f;
    private float rotDisp = 0.0f;

    // Sound Management
    public AudioSource fireSound;
    public int fireWait;

    private GameObject muzFlashObj; //This gun's instance of the muzzle flash prefab

    //Instantiate muzzle flash object on end of barrel
    void Start()
    {
        muzFlashObj = new GameObject("Muzzle Flash"); // Instance dummy object for now
        muzFlashObj.transform.parent = bulletspawn;
        muzFlashObj.transform.position = bulletspawn.transform.position + new Vector3(0, 0, 0.85f); //Offset from bulletspawn obj to end of barrel

    }

    //Firing the projectile
    void Fire()
    {
        if (fireWait == 0)
        {
            fireSound.Play();
            fireWait = 11;
        }
           barrelObj.Rotate(new Vector3(0, 0, rotDisp));
        RaycastHit hit;
        //Bullet Spread
        Vector3 Origin = bulletspawn.position + new Vector3(Random.Range(-0.05f, 0.05f), Random.Range(-0.05f, 0.05f), 0);
        Vector3 Direction = bulletspawn.forward + new Vector3(Random.Range(-0.02f, 0.02f), Random.Range(-0.02f, 0.02f), 0);

        if (Physics.Raycast(Origin, Direction, out hit, range)) //Hit in range
        {
            //Deal damage if we hit something living
            VitalSystem vitalSystem = hit.transform.gameObject.GetComponent<VitalSystem>();
            if (vitalSystem != null)
            {
                vitalSystem.DoDamage(damage);
            }
            //Impact Force on moveable hit
            if (hit.rigidbody != null)
            {
                hit.rigidbody.AddForce(-hit.normal * impctf);
            }

            //Bullet trail effect
            LineRenderer Trail = Instantiate(LinePrefab, Origin, bulletspawn.rotation);
            Trail.SetPosition(0, Origin);
            Trail.SetPosition(1, hit.point);
            Destroy(Trail.gameObject, 0.05f);
            
            //Spark effect
            GameObject spark = Instantiate(sparkPrefab, hit.point, Quaternion.LookRotation(hit.normal));
            Destroy(spark, 0.5f);
        }
        else //No hit in range
        {
            LineRenderer Trail = Instantiate(LinePrefab, Origin, bulletspawn.rotation);
            Trail.SetPosition(0, Origin);
            Trail.SetPosition(1, Origin + 100*Direction);
            Destroy(Trail.gameObject, 0.05f);
        }

    }

    //Enable and randomly orient the muzzle flash object
    void Flash()
    {
        return;
    }

    void Update()
    {
        bool state = SteamVR_Actions.default_Fire[hand].state;
        if (state) //If trigger is pulled
        {
            if (rotVel >= fireVel)
            {
                Fire();
                Flash();
            }
            else //Barrel Acceleration
            {
                rotDisp = rotVel * Time.deltaTime + 0.5f * rotAccel * Time.deltaTime * Time.deltaTime;
                barrelObj.Rotate(new Vector3(0, 0, rotDisp));
                rotVel += rotAccel * Time.deltaTime;

            }

        }
        else //Barrel Decceleration
        {
            if (rotVel > 0.0f)
            {
                rotDisp = rotVel * Time.deltaTime + 0.5f * -0.125f * rotAccel * Time.deltaTime * Time.deltaTime;
                barrelObj.Rotate(new Vector3(0, 0, rotDisp));
                rotVel += -0.125f * rotAccel * Time.deltaTime;
            }
            else if (rotVel < 0.0f)
            {
                rotVel = 0.0f;
            }

        }

        if (fireWait > 0)
        {
            fireWait = fireWait - 1;

        }
    }
}
//T
//An
