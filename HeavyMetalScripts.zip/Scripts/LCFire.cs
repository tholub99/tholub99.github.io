﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Valve.VR;

/* 
Name: LCFire
Purpose: Laser Cannon Firing Script
Version and date: 2.0 : 6/4/19
Author(s): Tristan H., David L.
Dependencies: None
*/

public class LCFire : MonoBehaviour
{
    public SteamVR_Input_Sources hand;
    public GameObject LaserPrefab;
    public Transform barreltip;
    public Transform gun;

    public int maxFireTime = 60; //How long the laser last
    public int maxCharge; //Charge Time
    public float range = 200f; //HitScan Range
    public float damage = 10.0f; //Damage ._.
    public float impctf = 120.0f; //Impact Force

    private float fireTime = 0; //Current Fire Time
    private bool firing; //Is the laser firing?
    private bool cooldown; //Has the laser just fired?
    private int charge = 0; //Current Charge
    private LineRenderer Beam; //Beam of Laser
    private GameObject Laser; //Full laser effect object

    // Sound Management
    public AudioSource chargingSound;
    public AudioSource fireSound;

    void Start()
    {
        Laser = Instantiate(LaserPrefab, barreltip) as GameObject;
        Beam = Laser.GetComponentInChildren<LineRenderer>();
        DisableLaser();
        firing = false;
    }

    void Update()
    {
        //Debug.DrawLine(gun.position, gun.forward * 10);
        bool charging = SteamVR_Actions.default_Fire[hand].state;
        if (charge >= maxCharge) // Done Charging
        {
            charge = 0;
            firing = true;
            cooldown = true;
            EnableLaser();
        }
        else if (charging && !cooldown && fireTime == 0) // Charging
        {
            charge++;
            if (!chargingSound.isPlaying)
            {
                chargingSound.Play();
            }
        }
        if (!charging)
        {
            cooldown = false;
            charge = 0;
            if (chargingSound.isPlaying)
            {
                chargingSound.Stop();
            }
        }
        if (firing) // Firing
        {
            if (chargingSound.isPlaying)
            {
                chargingSound.Stop();
            }
            Fire();
            UpdateLaser();
            fireTime++;
        }
        if (fireTime >= maxFireTime) // Done Firing
        {
            fireSound.Stop();
            firing = false;
            DisableLaser();
            fireTime = 0;
        }
    }

    void Fire()
    {
        if (!fireSound.isPlaying)
        {
            fireSound.Play();
        }
        RaycastHit hit;
        Vector3 Origin = barreltip.position;
        Vector3 Direction = barreltip.forward;
        if (Physics.Raycast(Origin, Direction, out hit, range)) //Hit in range
        {
            //Deal damage if we hit something living
            VitalSystem vitalSystem = hit.transform.gameObject.GetComponent<VitalSystem>();
            if (vitalSystem != null)
            {
                vitalSystem.DoDamage(damage);
            }
            //Impact Force on moveable hit
            if (hit.rigidbody != null)
            {
                hit.rigidbody.AddForce(-hit.normal * impctf);
            }

            //Laser Beam effect
            float dist = Vector3.Distance(hit.point, Origin);
            Beam.SetPosition(1, new Vector3 (0, 0, dist));
        }
        else //No hit in range
        {
            Beam.SetPosition(1, new Vector3 (0, 0, 200));
        }
    }
    void EnableLaser()
    {
        Laser.SetActive(true);
    }
    void UpdateLaser()
    {
        Laser.transform.position = barreltip.position;
    }
    void DisableLaser()
    {
        Laser.SetActive(false);
    }
}
