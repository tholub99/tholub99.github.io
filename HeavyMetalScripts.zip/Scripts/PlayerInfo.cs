﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class PlayerInfo
{
    private static int weaponR, weaponL, points;

    public static int WeaponRight
    {
        get
        {
            return weaponR;
        }
        set
        {
            weaponR = value;
        }
    }
    public static int WeaponLeft
    {
        get
        {
            return weaponL;
        }
        set
        {
            weaponL = value;
        }
    }
    public static int Points
    {
        get
        {
            return points;
        }
        set
        {
            points = value;
        }
    }
}
