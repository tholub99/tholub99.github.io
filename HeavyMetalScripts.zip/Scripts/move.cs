﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
using Valve.VR;

/* 
Name: Move 
Purpose: Move the Player's Mech
Version and date: 1.0 : 5/9/19 
Author(s): Tristan H.
Dependencies: None
*/

public class move : MonoBehaviour
{
    public Transform mech;
    public float movespeed = 10.0f;
    public float turnspeed = 10.0f;
    public float vertspeed = 3f;
    public float offset = 5.75f;

    private Vector3 moveTo;
    private NavMeshAgent navMeshAgent;
    private float origin;
    private bool gleft;
    private bool gright;

    // Sound Management
    public AudioSource stepSound;

    
    void Start()
    {
        origin = mech.transform.position.y; //Origin height pos
        navMeshAgent = gameObject.GetComponent<NavMeshAgent>();
    }

    
    void Update()
    {
        //Grip Buttons Boolean Values
        gleft = SteamVR_Actions.default_Move[SteamVR_Input_Sources.LeftHand].state;
        gright = SteamVR_Actions.default_Move[SteamVR_Input_Sources.RightHand].state;

        if (gleft == true && gright == false)
        {
            mech.Rotate(Vector3.up, -turnspeed * Time.deltaTime); //Turn Right
        }
        else if (gright == true && gleft == false)
        {
            mech.Rotate(Vector3.up, turnspeed * Time.deltaTime); //Turn Left
        }
        else if (gright == true && gleft == true)
        {
            mech.Translate(Vector3.forward * movespeed * Time.deltaTime); //Move Forward
            bobbing();
        }
        if (gright == false && gleft == false) //reset on movement stop
        {
            moveTo = new Vector3(mech.transform.position.x, origin, mech.transform.position.z);
            mech.transform.position = Vector3.MoveTowards(mech.transform.position, moveTo, (vertspeed*0.5f) * Time.deltaTime);
        }

    }
    //Create up/down movement during forward walk
    void bobbing()
    {
        if (mech.transform.position.y < (origin + 0.1f)) // Moving up
        {
            moveTo = new Vector3(mech.transform.position.x, offset, mech.transform.position.z);
            if (!stepSound.isPlaying) // Start sound
            {
                stepSound.Play();
            }
        }
        if (mech.transform.position.y > (offset - 0.1f)) // Moving down
        {
            moveTo = new Vector3(mech.transform.position.x, origin, mech.transform.position.z);
            if (stepSound.isPlaying) // Stop sound
            {
                stepSound.Stop();
            }
        }
        mech.transform.position = Vector3.MoveTowards(mech.transform.position, moveTo, vertspeed * Time.deltaTime);
    }
} 
