﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SetWeapons : MonoBehaviour
{
    private string hand;
    public void HandSet(string handvalue)
    {
        hand = handvalue;
    }
    public void WeaponSet(int weapon)
    {
        if(hand == "left")
        {
            PlayerInfo.WeaponLeft = weapon;
            Debug.Log(weapon);
        }
        if(hand == "right")
        {
            PlayerInfo.WeaponRight = weapon;
            Debug.Log(weapon);
        }
    }
}
