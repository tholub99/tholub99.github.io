﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/* 
Name: AimGuideLine
Purpose: Provide Reference for Player Aiming
Version and date: 1.0 : 5/9/19
Author(s): Tristan H.
Dependencies: None
*/

public class AimGuideLine : MonoBehaviour
{
    private LineRenderer lineRenderer;
    private float counter;
    private float dist;

    public Transform controller;
    public Transform centersphere;

    public float speed = 6f;

    //Linerenderer basics
    void Start()
    {
        lineRenderer = GetComponent<LineRenderer>();
        lineRenderer.SetPosition(0, controller.position);
    }

    //Creates a line between the centersphere and the controller to add reference for the player
    void Update()
    {            
        lineRenderer.SetPosition(0, controller.position);
        lineRenderer.SetPosition(1, centersphere.position);

        dist = Vector3.Distance(controller.position, centersphere.position);
        if (dist >= 0.25)
        {
            lineRenderer.enabled = false;
        }
        else
        {
            lineRenderer.enabled = true;
        }



    }
}
