﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

/* 
Name: UIControllerLasers
Purpose: Lasers when interacting with UI
Version and date: 1.0 : 5/9/19
Author(s): Tristan H.
Dependencies: None
*/

public class UIControllerLasers : MonoBehaviour
{
    private LineRenderer Laser;

    public GameObject controller; //Laser Origin
    public GameObject flareprefab; //Collider Hit Flare
    public float offset;

    private RaycastHit hit; //Laser Hit
    private bool laserhit = false;
    private GameObject flare;

    void Start()
    {
        Laser = GetComponent<LineRenderer>(); //LineRendererInitialization
    }


    void Update()
    {
        Vector3 point = controller.transform.TransformPoint(Vector3.forward * 10);
        Laser.SetPosition(0, controller.transform.position); //LaserOriginUpdate
        LayerMask mask = LayerMask.GetMask("UI");
        if (Physics.Raycast(controller.transform.position, controller.transform.TransformDirection(Vector3.forward), out hit, 10, mask)) //PointerRayCheck

        {
            Laser.SetPosition(1, hit.point); //LaserHitUpdate
            Debug.Log(hit.collider.gameObject.name);
            hit.collider.gameObject.SendMessage("CollisionCheck");

            if (!laserhit)
            {
                flare = Instantiate(flareprefab, hit.point - (hit.point - controller.transform.position).normalized * offset, Quaternion.LookRotation(hit.normal));
                laserhit = true;
            }
            if (laserhit)
            {
                flare.transform.position = hit.point - (hit.point - controller.transform.position).normalized * offset;
            }

        }
        else
        {
            Laser.SetPosition(1, point); //LaserNoHitUpdate
            laserhit = false;
            Destroy(flare);
        }
    }
}
