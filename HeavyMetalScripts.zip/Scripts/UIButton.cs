﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Valve.VR;

/* 
Name: UIButton
Purpose: Direct button actions
Version and date: 1.0 : 5/9/19 
Author(s): Tristan H., Adin S.
Dependencies: UIControllerLasers
*/

public class UIButton : MonoBehaviour
{
    public Button button;
    public Color hovercolor;
    bool checkcol = false;
    public Color normalcolor;
    public bool unClicked = true;
    public float clickCooldown = 0;
    
    void Update()
    {
        if (checkcol)
        {
            bool state = SteamVR_Actions.default_Fire[SteamVR_Input_Sources.RightHand].state;
            Debug.Log("Selected");
            button.image.color = hovercolor;

            if (state && unClicked && clickCooldown == 0) // Conditions that the button can be clicked: trigger pressed, separate click, and at least .6 seconds after the previous click
            {
                Debug.Log("Clicked");
                unClicked = false;
                clickCooldown = 60;
                button.onClick.Invoke();
            }
            if (clickCooldown > 0) // Ensure that two clicks can't happen within .6 seconds within one another
            {
                clickCooldown = clickCooldown - 1;
            }
            if (!state) // Once no longer clicked, allow for another click
            {
                unClicked = true;
            }
            checkcol = false;
        }
        else
        {
            button.image.color = normalcolor;
        }
    }

    public void CollisionCheck()
    {
        Debug.Log("Collision!!!");
        checkcol = true;
    }

}

    
