﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/* 
Name: ControlSphereBehaivor
Purpose: Aim Weapons Based on User Controller Positions
Version and date: 1.0 : 5/9/19 
Author(s): Tristan H.
Dependencies: None
*/

public class ControlSphereBehaivor : MonoBehaviour
{
    public GameObject centersphere;
    public GameObject controller;
    public GameObject gun;

    void Update()
    {
        float dist = Vector3.Distance(centersphere.transform.position, controller.transform.position); //Takes distance between controls and center of control spheres
        if (dist <= 0.25)
        {
            Aim();
        }
    }
    //Takes a vector of direction between controller and center control sphere, which the gun then mimics to aim
    void Aim()
    {
        Vector3 direction = centersphere.transform.position - controller.transform.position;
        Quaternion rotation = Quaternion.LookRotation(direction, Vector3.up);
        
        gun.transform.rotation = rotation;
    }
}
