﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/* 
Name: LaserSight
Purpose: Lasersights on Weapons
Version and date: 2.0 : 5/9/19
Author(s): Tristan H.
Dependencies: None
*/

public class LaserSight : MonoBehaviour
{
    private LineRenderer Laser;

    public GameObject gun; //Laser Origin
    public GameObject flareprefab; //Collider Hit Flare
    public float offset;

    private RaycastHit hit; //Laser Hit
    private bool laserhit = false;
    private GameObject flare;

    void Start()
    {
        Laser = GetComponent<LineRenderer>(); //LineRendererInitialization
    }


    void Update()
    {
        int layermask = 1 << 8;
        layermask = ~layermask;
        Vector3 point = gun.transform.TransformPoint(Vector3.forward * 100);
        Laser.SetPosition(0, gun.transform.position); //LaserOriginUpdate

        if (Physics.Raycast(gun.transform.position, gun.transform.TransformDirection(Vector3.forward), out hit, 100, layermask)) //GunRayCheck
        {
            Laser.SetPosition(1, hit.point); //LaserHitUpdate
            if(!laserhit)
            {
                flare = Instantiate(flareprefab, hit.point - (hit.point - gun.transform.position).normalized * offset, Quaternion.LookRotation(hit.normal));
                laserhit = true;
            }
            if(laserhit)
            {
                flare.transform.position = hit.point - (hit.point - gun.transform.position).normalized * offset;
            }
            
        }
        else
        {
            Laser.SetPosition(1, point); //LaserNoHitUpdate
            laserhit = false;
            Destroy(flare);
        }
    }
}
