﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class FarmerController : MonoBehaviour
{
    public NavMeshAgent agent;
    private List<GameObject> targetFarms;
    private Transform escapePoint;
    private Vector3 currentDest;
    private float harvestTime;
    private float harvestTimeRemaining;
    private int farmNum;
    private bool destSet;

    void Start()
    {
        harvestTime = 2;
        harvestTimeRemaining = harvestTime;
        farmNum = 0;
        destSet = false;
    }

    void Update()
    {
        if (farmNum < targetFarms.Count)
        {
            if (!destSet)
            {
                agent.SetDestination(targetFarms[farmNum].transform.GetChild(3).position);
                currentDest = targetFarms[farmNum].transform.GetChild(3).position;
                destSet = true;
            }
            if (Mathf.Abs(agent.transform.position.x - currentDest.x) <= agent.stoppingDistance && Mathf.Abs(agent.transform.position.z - currentDest.z) <= agent.stoppingDistance)
            {
                if(harvestTimeRemaining == harvestTime)
                {
                    FarmReset(targetFarms[farmNum]);
                }
                harvestTimeRemaining -= Time.deltaTime;
            }
            if (harvestTimeRemaining <= 0)
            {
                farmNum++;
                harvestTimeRemaining = harvestTime;
                destSet = false;
            }
        }
        else if(farmNum >= targetFarms.Count)
        {
            if (!destSet)
            {
                agent.SetDestination(escapePoint.position);
                currentDest = escapePoint.position;
                destSet = true;
            }
            if (Mathf.Abs(agent.transform.position.x - currentDest.x) <= agent.stoppingDistance && Mathf.Abs(agent.transform.position.z - currentDest.z) <= agent.stoppingDistance)
            {
                Destroy(agent.gameObject);
                destSet = false;
            }
        }
    }

    public void SetTargets(List<GameObject> Farms, Transform Exit)
    {
        targetFarms = Farms;
        escapePoint = Exit;
    }

    private void FarmReset(GameObject currentFarm)
    {
        CheckBeds Bed = currentFarm.GetComponent<CheckBeds>();
        Bed.Plant();
    }
}
