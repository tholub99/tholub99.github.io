﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScrollingBackground : MonoBehaviour
{
    public float Speed;
    public Renderer backGroundRender;

    void Update()
    {
        backGroundRender.material.mainTextureOffset += new Vector2(Speed * Time.deltaTime, 0f);
        
    }
}
