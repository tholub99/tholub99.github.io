﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class BunnyController : MonoBehaviour
{
    public NavMeshAgent agent;
    public Vector3 targetFarm;
    public Vector3 escapePoint;
    public AudioClip[] bunSqueals;
    private Animation anim;
    AudioSource bunAudio;


    private Vector3 currentDest;
    public GameObject gameMaster;

    void Start()
    {
        GoFarm();
        gameMaster.GetComponent<GameMain>().AddBunny();
        bunAudio = GetComponent<AudioSource>();
        bunAudio.clip = bunSqueals[Random.Range(0,2)];
        anim = gameObject.GetComponentInChildren<Animation>();
    }

    void Update()
    {
        float dist = Vector3.Distance(agent.transform.position, currentDest);
        if (dist <= agent.stoppingDistance) //If agent is stopped
        {
            if (currentDest == targetFarm) //Agent is at a farm
            {
                //something about eating animations
            }
            if (currentDest == escapePoint) //Agent has escaped
            {
                gameMaster.GetComponent<GameMain>().RemoveBunny();
                Destroy(agent.gameObject);
            }
        }
        else
        {
            anim.Play("Jump");
        }
    }
    private void OnTriggerEnter(Collider col)
    {
        if (col.tag == "Thunder") //Agent scared by thunder
        {
            bunAudio.Play();
            GoExit(); 
        }
    }
    public void SetTargets(Vector3 farm, Vector3 escape) //public script function for assigning target destinations
    {
        targetFarm = farm;
        escapePoint = escape;
    }

    public void GoFarm()
    {
        currentDest = targetFarm;
        agent.SetDestination(targetFarm);
    }
    public void GoExit()
    {
        currentDest = escapePoint;
        agent.SetDestination(escapePoint);
    }

    public void SetGameMaster(GameObject GM)
    {
        gameMaster = GM;
    }
}
