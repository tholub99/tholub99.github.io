﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CloudScript : MonoBehaviour
{
    public Transform cloud;
    public GameObject boltBox;
    public GameObject[] bolts;
    public GameObject gameMaster;
    public ParticleSystem rain;
    public GameObject rainBox;
    public GameObject boltNotif;
    public AudioClip lightningClip;
    public AudioClip rainClip;
    AudioSource[] audioSources;

    private float thunderTime;
    private int boltSelect;
    public float moveSpeed = 5f;
    public float rainMeter = 100f;
    public RectTransform rainTransform;
    public float minRainVal;
    public float maxRainVal;
    public float rainX;
    public float rainZ;

    private void Start()
    {
        rainBox.SetActive(false);
        boltBox.SetActive(false);
        for(int i = 0; i < bolts.Length; i++)
        {
            bolts[i].SetActive(false);
        }
        thunderTime = 0f;

        rainX = rainTransform.localPosition.x;
        rainZ = rainTransform.localPosition.z;
        maxRainVal = rainTransform.localPosition.y;
        minRainVal = rainTransform.localPosition.y - rainTransform.rect.height;

        audioSources = GetComponents<AudioSource>();
        audioSources[0].clip = rainClip;
        audioSources[1].clip = lightningClip;
    }

    void Update()
    {
        Vector3 cloudPos = cloud.position; //Move
        if(Input.GetKey(KeyCode.LeftArrow) && cloud.position.x > -2.5)
        {
            cloud.Translate(Vector3.left * moveSpeed * Time.deltaTime);
        }
        if (Input.GetKey(KeyCode.RightArrow) && cloud.position.x < 2.5)
        {
            cloud.Translate(Vector3.right * moveSpeed * Time.deltaTime);
        }
        if (Input.GetKey(KeyCode.UpArrow) && cloud.position.z < 2.5)
        {
            cloud.Translate(Vector3.forward * moveSpeed * Time.deltaTime);
        }
        if (Input.GetKey(KeyCode.DownArrow) && cloud.position.z > -2.5)
        {
            cloud.Translate(Vector3.back * moveSpeed * Time.deltaTime);
        }

        if (rainMeter > 30f)
        {
            if (!boltNotif.activeSelf)
            {
                boltNotif.SetActive(true);
            }
        }
        else
        {
            if(boltNotif.activeSelf)
            {
                boltNotif.SetActive(false);
            }
        }

        if (Input.GetKey(KeyCode.Space) && rainMeter >= 0f) //Raining
        {
            bool activeWave = gameMaster.GetComponent<GameMain>().IsActiveWave();
            rainBox.SetActive(true);
            if(!rain.isPlaying)
            {
                audioSources[0].Play();
                rain.Play();
            }
            if (activeWave)
            {
                rainMeter -= Time.deltaTime * 5;
                RainDrain(rainMeter);
            }
        }
        else //Not Raining
        {
            rainBox.SetActive(false);
            if(rain.isPlaying)
            {
                audioSources[0].Stop();
                rain.Stop();
            }
        }

        if (Input.GetKeyDown(KeyCode.LeftShift) && rainMeter >= 30f && thunderTime == 0f)
        {
            audioSources[1].Play();
            boltBox.SetActive(true);
            boltSelect = Random.Range(0, 3);
            bolts[boltSelect].SetActive(true);
            thunderTime = .5f;
        }
        else if (thunderTime > 0f)
        {
            thunderTime -= Time.deltaTime;
        }
        else
        {
            boltBox.SetActive(false);
            bolts[boltSelect].SetActive(false);
            thunderTime = 0f;
        }
    }
    public void RainDrain(float x)
    {
        float newRainBarY = TranslateBar(x, minRainVal, maxRainVal);
        rainTransform.localPosition = new Vector3(rainX, newRainBarY, rainZ);
    }

    private float TranslateBar(float x, float minY, float maxY) //Rain Bar Position Calculator
    {
        return x * (0 - minY) / 100f + minY;
    }
}
