﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PuddleScript : MonoBehaviour
{
    //private float Water;
    //public float maxWater = 50f;
    public GameObject waterEvap;
    public GameObject gameMaster;
    public int wave;
    //public float respawnTime;
    //public float maxRespawn = 10f;
    void Start()
    {
        //waterEvap.SetActive(false);
        //respawnTime = maxRespawn;
        //Water = maxWater;
        wave = gameMaster.GetComponent<GameMain>().Wave;
    }

    void Update()
    {
        /*if (!waterEvap.activeSelf)
        {
            respawnTime -= Time.deltaTime;
        }

        if(respawnTime <= 0f)
        {
            waterEvap.SetActive(true);
        }*/
    }
    private void OnTriggerStay(Collider col) //Cloud meets watersource
    {
        if (col.tag == "Player")
        {
            CloudScript cloud = col.GetComponentInParent<CloudScript>();
            if (cloud.rainMeter < 100f)
            {
                cloud.rainMeter += Time.deltaTime * (4 + wave);
                cloud.RainDrain(cloud.rainMeter);
                //Water -= Time.deltaTime * 10;
            }
            /*else //Water source is out of water or cloud is full
            {
                waterEvap.SetActive(false);
                respawnTime = maxRespawn;
                Water = maxWater;
            }*/
            
        }
    }
    /*private void OnTriggerExit(Collider other) //Cloud leaves water source
    {
        waterEvap.SetActive(false);
        respawnTime = maxRespawn;
        Water = maxWater;
    }*/
}
