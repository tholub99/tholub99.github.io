﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MenuMaster : MonoBehaviour
{
    public Texture2D cursorTex;
    void Start()
    {
        float xspot = cursorTex.width / 4;
        float yspot = cursorTex.height / 4;
        Cursor.SetCursor(cursorTex, new Vector2 (xspot, yspot), CursorMode.ForceSoftware);
    }
}
