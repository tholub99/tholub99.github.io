﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class SpawnEnemy : MonoBehaviour
{
    public int bunnyCount = 0;
    public GameObject bunnyPrefab;
    private int chooseFarm;

    public GameObject Farm1;
    public Transform Escape1;
    public GameObject Farm2;
    public Transform Escape2;
    public GameObject gameMaster;
    private CheckBeds checkBedOne;
    private CheckBeds checkBedTwo;


    public float maxEnemies;
    private float spawnPeriod;
    public bool activeSpawn;

    void Start()
    {
        StartSpawners();
        checkBedOne = Farm1.GetComponent<CheckBeds>();
        checkBedTwo = Farm2.GetComponent<CheckBeds>();
    }

    void Spawn()
    {
        if (activeSpawn)
        {
            chooseFarm = Random.Range(1, 11);
            Vector3 spawnPoint = new Vector3(gameObject.transform.position.x, 0, gameObject.transform.position.z);
            if (chooseFarm < 6 && checkBedOne.IsGrown())
            {
                GameObject bunnyAgent = Instantiate(bunnyPrefab, spawnPoint, Quaternion.identity);
                Debug.Log(spawnPoint);
                bunnyAgent.GetComponent<BunnyController>().SetTargets(Farm1.transform.position, Escape1.position);
                bunnyAgent.GetComponent<BunnyController>().SetGameMaster(gameMaster);
            }
            else if (checkBedTwo.IsGrown())
            {
                GameObject bunnyAgent = Instantiate(bunnyPrefab, spawnPoint, Quaternion.identity);
                Debug.Log(spawnPoint);
                bunnyAgent.GetComponent<BunnyController>().SetTargets(Farm2.transform.position, Escape2.position);
                bunnyAgent.GetComponent<BunnyController>().SetGameMaster(gameMaster);
            }
        }
    }

    IEnumerator Spawner()
    {
        while (activeSpawn)
        {
            spawnPeriod = Random.Range(8f, 13f);
            yield return new WaitForSeconds(spawnPeriod);
            Spawn();
        }
    }

    public void StopSpawners()
    {
        activeSpawn = false;
        StopCoroutine(Spawner());
    }
    public void StartSpawners()
    {
        activeSpawn = true;
        StartCoroutine(Spawner());
    }
}
