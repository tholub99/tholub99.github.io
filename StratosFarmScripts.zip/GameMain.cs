﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.AI;

public class GameMain : MonoBehaviour
{
    //IMPLEMENT: GAME GLOBAL VARIABLES (Score), SCORE COUNTER
    public GameObject[] Farms;
    public GameObject[] Spawners;
    public GameObject farmerPrefab;
    public GameObject scoreBoard;
    public GameObject countClock;
    public GameObject cloud;
    public TextMeshProUGUI waveClock;
    public TextMeshProUGUI scoreText;
    public Transform farmerSpawn;
    public Texture2D cursorTex;

    public GameObject[] emptyStars;
    public GameObject[] fullStars;


    private List<int> waveScores = new List<int>();
    private List<GameObject> activeFarms = new List<GameObject>();
    private TextMeshProUGUI countDown;

    public int Wave;
    public float waveTime;
    public float betweenWaveTime;

    private int finalScore;
    private float betweenWaveTimeRemaining;
    private float waveTimeRemaining;
    private bool activeWave;
    private bool activeFarmer;

    public int activeRabbits;
    void Start()
    {
        activeRabbits = 0;
        Wave = 1;
        waveTime = 25;
        betweenWaveTime = 20;
        waveTimeRemaining = waveTime;
        betweenWaveTimeRemaining = betweenWaveTime;
        activeWave = true;
        UpdateClock(Wave, waveTimeRemaining, activeWave);
        SetFarms(Wave);
        ActivateFarms(true);
        InitializeGame();
        countDown = countClock.GetComponent<TextMeshProUGUI>();
        SetCursor();
    }

    void Update()
    {
        if(Wave <= 4)
        {
            Debug.Log("WAVE: " + Wave);
            HandleTime();
        }
        else
        {
            Debug.Log("No More Waves");
            FinalScore();
            scoreBoard.SetActive(true);
            Cursor.visible = true;
        }
    }

    void HandleTime()
    {
        if (activeWave)
        {
            if(waveTimeRemaining > 0)
            {
                waveTimeRemaining -= Time.deltaTime;
                UpdateClock(Wave, waveTimeRemaining, activeWave);
            }
            if(waveTimeRemaining <= 0)
            {
                ActivateSpawners(false);
                ActivateFarms(false);
                StartCoroutine(DisableCountDown());
            }
            if(waveTimeRemaining <= 0 && activeRabbits == 0)
            {
                activeWave = false;
            }
            
        }
        else if (Wave < 4)
        {
            if (!activeFarmer)
            {
                Score();
                activeFarmer = true;
                SetFarms(Wave + 1);
                SpawnFarmer();
            }

            if (betweenWaveTimeRemaining > 0)
            {
                betweenWaveTimeRemaining -= Time.deltaTime;
                UpdateClock(Wave, betweenWaveTimeRemaining, activeWave);
            }

            if (betweenWaveTimeRemaining <= 0)
            {
                NextWave();
                activeWave = true;
                activeFarmer = false;
            }
        }
        else
        {
            if (!activeFarmer)
            {
                activeFarmer = true;
                SpawnFarmer();
            }
            Wave++;
        }
    }

    void NextWave()
    {
        Wave++;
        StartCoroutine(DisableCountDown());
        waveTimeRemaining = waveTime * Wave;
        betweenWaveTimeRemaining = betweenWaveTime;
        ActivateFarms(true);
        ActivateSpawners(true);
    }

    void UpdateClock(int waveNumber, float timeRemaining, bool isActiveWave)
    {
        string clockTime;
        int properTimeRemaining = (int) Mathf.Round(timeRemaining);
        if (timeRemaining != 0)
        {
            string waveMin = (properTimeRemaining / 60).ToString("D2");
            string waveSec = (properTimeRemaining % 60).ToString("D2");
            clockTime = (waveMin + ":" + waveSec);
        }
        else
        {
            clockTime = "00:00";
        }
        if (isActiveWave)
        {
            waveClock.text = ("Wave - " + waveNumber + "\nTime Remaining\n" + clockTime);
            if (properTimeRemaining < 5 && properTimeRemaining > 0)
            {
                if (!countClock.activeSelf)
                {
                    countClock.SetActive(true);
                }
                countDown.text = properTimeRemaining.ToString("D1");
            }
            if (properTimeRemaining == 0)
            {
                countDown.text = ("Wave Over!");
            }
        }
        else
        {
            waveClock.text = ("Wave - " + waveNumber + "\nWave Starts In\n" + clockTime);
            if (properTimeRemaining < 5 && properTimeRemaining > 0)
            {
                if (!countClock.activeSelf)
                {
                    countClock.SetActive(true);
                }
                countDown.text = properTimeRemaining.ToString("D1");
            }
            if (properTimeRemaining == 0)
            {
                countDown.text = ("Go!");
            }
        }
        
    }

    void SetFarms(int waveNum)
    {
        GameObject newFarm = Farms[waveNum - 1];
        activeFarms.Add(newFarm);
    }

    void ActivateSpawners(bool active)
    {
        foreach (GameObject s in Spawners)
        {
            SpawnEnemy spawnEnemy = s.GetComponent<SpawnEnemy>();
            if (active)
            {
                spawnEnemy.StartSpawners();
            }
            else
            {
                spawnEnemy.StopSpawners();
            }
        }
    }

    void ActivateFarms(bool active)
    {
        foreach(GameObject farm in activeFarms)
        {
            farm.GetComponent<CheckBeds>().isActive = active;
            farm.GetComponent<CheckBeds>().outOfTime = !active;
        }
    }

    public void AddBunny()
    {
        activeRabbits += 1;
    }

    public void RemoveBunny()
    {
        activeRabbits -= 1;
    }

    void SpawnFarmer()
    {
        GameObject FarmerAgent = Instantiate(farmerPrefab, new Vector3(farmerSpawn.position.x, farmerSpawn.position.y,farmerSpawn.position.z), Quaternion.identity);
        //FarmerAgent.GetComponent<NavMeshAgent>().Warp(new Vector3(farmerSpawn.position.x, farmerSpawn.position.y, farmerSpawn.position.z));
        FarmerAgent.GetComponent<FarmerController>().SetTargets(activeFarms, farmerSpawn);
    }

    void InitializeGame()
    {
        activeFarms[0].GetComponent<CheckBeds>().Plant();
    }

    void Score()
    {
        int cropScore = 0;
        float cropScoreRatio = (100 / 6);
        foreach (GameObject farm in activeFarms)
        {
            float cropGrowth = farm.GetComponent<CheckBeds>().cropGrowth;
            if (cropGrowth > cropScoreRatio && cropGrowth <= cropScoreRatio * 2)
            {
                cropScore += 1;
            }
            else if (cropGrowth > cropScoreRatio * 2 && cropGrowth <= cropScoreRatio * 3)
            {
                cropScore += 2;
            }
            else if (cropGrowth > cropScoreRatio * 3 && cropGrowth <= cropScoreRatio * 4)
            {
                cropScore += 3;
            }
            else if (cropGrowth > cropScoreRatio * 4 && cropGrowth <= cropScoreRatio * 5)
            {
                cropScore += 4;
            }
            else if (cropGrowth > cropScoreRatio * 5)
            {
                cropScore += 5;
            }
        }
        cropScore = (cropScore / activeFarms.Count);
        waveScores.Add(cropScore);
    }

    void FinalScore()
    {
        finalScore = 2;
        foreach(int Score in waveScores)
        {
            finalScore += Score;
        }
        finalScore = (finalScore / 4);
        Debug.Log(finalScore);
        scoreText.text = ("SCORE: " + finalScore + "/5");
        for(int i = 0; i < finalScore; i++)
        {
            emptyStars[i].SetActive(false);
            fullStars[i].SetActive(true);
        }
    }

    public bool IsActiveWave()
    {
        return activeWave;
    }

    IEnumerator DisableCountDown()
    {
        yield return new WaitForSeconds(1);
        countClock.SetActive(false);
    }

    void SetCursor()
    {
        float xspot = cursorTex.width / 4;
        float yspot = cursorTex.height / 4;
        Cursor.SetCursor(cursorTex, new Vector2(xspot, yspot), CursorMode.ForceSoftware);
    }
}
