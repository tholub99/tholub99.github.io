﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CheckBeds : MonoBehaviour
{
    public GameObject Bed;
    public GameObject Crop;
    public Animation[] cropAnims;
    public GameObject bunnyAlert;
    public GameObject dryAlert;
    public AudioSource bunAudio;
    public bool lowCrop;
    public bool tomatoCrop;
    private Animation[] anims;

    public bool isActive = false;
    public bool outOfTime = false;
    public float cropGrowth;
    public float baseHeight;
    private float hiddenHeight;
    private float dryOutTime;
    public bool rainBoxActive;
    private int bunnyNumber;
    private readonly float cropRatio = 50f/0.225f;
    private string growAnim;
    private float growRatio;
    

    void Start()
    {
        cropGrowth = 0;
        bunnyNumber = 0;
        dryOutTime = 0;
        baseHeight = -0.45f;
        dryAlert.SetActive(false);
        bunnyAlert.SetActive(false);
        if (lowCrop)
        {
            growAnim = "LowGrow";
            growRatio = 98.0f;
        }
        else if (tomatoCrop)
        {
            growAnim = "TomatoGrow";
            growRatio = 98.0f;
        }
        else
        {
            growAnim = "CornGrow";
            growRatio = 98.0f;
        }
        anims = Crop.GetComponentsInChildren<Animation>();
        for (int i = 0; i < anims.Length; i++)
        {
            anims[i][growAnim].speed = 0;
            anims[i]["Wiggle"].speed = 0.5f;
        }
    }
    void Update()
    {
        DryOutAlertSystem(false);
        BunnyAlertSystem();
    }
    private void OnTriggerStay(Collider col)
    {
        if (col.tag == "Rain" && isActive)
        {
            DryOutAlertSystem(true);
            if (cropGrowth < 100)
            {
                cropGrowth += Time.deltaTime * 10;
                GrowCrop();
            }
            else
            {
                Debug.Log("Fully Grown");
            }
        }
        if(col.tag == "Enemy")
        {
            if (cropGrowth > 0)
            {
                cropGrowth -= Time.deltaTime * (2 * bunnyNumber);
                GrowCrop();
            }
            else
            {
                col.GetComponent<BunnyController>().GoExit();
            }

            if (outOfTime)
            {
                col.GetComponent<BunnyController>().GoExit();
            }
        }
    }
    private void OnTriggerEnter(Collider col)
    {
        if(col.tag == "Enemy")
        {
            bunnyNumber++;
        }
    }
    private void OnTriggerExit(Collider col)
    {
        if(col.tag == "Enemy")
        {
            bunnyNumber--;
        }
    }

    public bool IsGrown()
    {
        if(cropGrowth > 0)
        {
            return true;
        }
        return false;
    }

    public void GrowCrop()
    {
        for (int i = 0; i < cropAnims.Length; i++)
        {
            anims[i][growAnim].time = ((100f/30f)/60f) + (cropGrowth/60f)/(30f/29f);
            anims[i].Play(growAnim);
        }
    }

    private void DryOutAlertSystem(bool beingWatered)
    {
        if (isActive)
        {
            if (dryOutTime < 14 && !beingWatered && cropGrowth > 0)
            {
                dryOutTime += Time.deltaTime;
                dryAlert.SetActive(false);
            }
            if (dryOutTime >= 8)
            {
                dryAlert.SetActive(true);
            }
            if (dryOutTime >= 14)
            {
                dryAlert.SetActive(false);
                Plant();
            }
            if (beingWatered && dryOutTime > 0)
            {
                dryOutTime = 0;
            }
        }
        else
        {
            dryAlert.SetActive(false);
            dryOutTime = 0;
        }
    }

    private void BunnyAlertSystem()
    {
        if(bunnyNumber > 0 && !bunAudio.isPlaying)
        {
            bunAudio.Play();
        }
        else if(bunnyNumber < 1 && bunAudio.isPlaying)
        {
            bunAudio.Pause();
        }

        if (bunnyNumber >= 2)
        {
            bunnyAlert.SetActive(true);
        }
        else
        {
            bunnyAlert.SetActive(false);
        }
    }

    public void Plant()
    {
        Crop.SetActive(true);
        cropGrowth = 0;
        GrowCrop();
    }
}

