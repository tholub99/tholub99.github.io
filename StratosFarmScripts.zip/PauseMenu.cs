﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PauseMenu : MonoBehaviour
{
    public static bool isPaused = false;
    public GameObject controlStartMenu;

    public GameObject pauseMenu;

    private GameObject activeMenu;

    private void Start()
    {
        controlStartMenu.SetActive(true);
        activeMenu = controlStartMenu;
        Pause();
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (isPaused)
            {
                Resume();
            }
            else
            {
                PauseMen();
            }
        }
    }

    public void Resume()
    {
        activeMenu.SetActive(false);
        UnPause();
    }

    void PauseMen()
    {
        activeMenu = pauseMenu;
        pauseMenu.SetActive(true);
        Pause();
    }

    public void LoadMenu()
    {
        UnPause();
        Cursor.visible = true;
        SceneManager.LoadScene(0);
    }

    public void QuitGame()
    {
        Debug.Log("Quit");
        Application.Quit();
    }

    public void UnPause()
    {
        isPaused = false;
        Cursor.visible = false;
        Time.timeScale = 1f;
    }

    public void Pause()
    {
        Time.timeScale = 0f;
        Cursor.visible = true;
        isPaused = true;
    }
}
