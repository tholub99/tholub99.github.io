#version 330 core
in vec3 normal;
in vec3 position;
in vec2 texcoord;

struct Light { 
    vec3 ambient;
    vec3 diffuse;
    vec3 specular;
};

uniform sampler2D tex;
uniform vec3 sun_position; 
uniform vec3 sun_color; 
uniform vec3 view_position;
uniform Light light;

out vec4 color;
void main() {
    // ambient
    vec3 ambient = light.ambient * texture(tex,texcoord).rgb;
  	
    // diffuse 
    vec3 norm = normalize(normal);
    vec3 lightDir = normalize(sun_position - position);
    float diff = max(dot(norm, lightDir), 0.0);
    vec3 diffuse = light.diffuse * diff * texture(tex,texcoord).rgb;  
    
    // specular
    vec3 viewDir = normalize(view_position - position);
    vec3 halfwarDir = normalize(lightDir + viewDir);  
    float spec = pow(max(dot(norm, halfwarDir), 0.0), 32.0);
    vec3 specular = light.specular * spec * texture(tex,texcoord).rgb;  
        
    vec3 result = ambient + diffuse + specular;
    color = vec4(result, 1.0);
}