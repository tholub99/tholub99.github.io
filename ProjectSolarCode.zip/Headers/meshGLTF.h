#pragma once
#ifndef MESHGLTF_H
#define MESHGLTF_H

#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "tiny_gltf.h"
#include "stb_image.h"
#include "json.hpp"
#include "shader.h"

#include <string>
#include <iostream>
#include <fstream>
#include <map>
#include <vector>

#define BUFFER_OFFSET(i) ((char *)NULL + (i))

struct Texture {
    unsigned int id;
};

class MeshGLTF {
public:
    GLuint VAO;
    Texture texture;
    std::vector<tinygltf::Accessor> accessors;
    tinygltf::Mesh mesh;


    MeshGLTF(GLuint VAO, tinygltf::Mesh mesh, Texture texture, std::vector<tinygltf::Accessor> accessors)
    {
        this->VAO = VAO;
        this->mesh = mesh;
        this->texture = texture;
        this->accessors = accessors;
    }

    void drawMesh(Shader activeShader)
    {
        glBindVertexArray(VAO);
        activeShader.use();
        for (size_t i = 0; i < mesh.primitives.size(); ++i)
        {
            tinygltf::Primitive primitive = mesh.primitives[i];
            tinygltf::Accessor indexAccessor = accessors[primitive.indices];

            glActiveTexture(GL_TEXTURE0);
            activeShader.setInt("tex", 0);
            glBindTexture(GL_TEXTURE_2D, texture.id);

            glDrawElements(primitive.mode, indexAccessor.count, indexAccessor.componentType, BUFFER_OFFSET(indexAccessor.byteOffset));
        }
        glBindVertexArray(0);
        glActiveTexture(GL_TEXTURE0);
    }

    void drawMeshInstanced(Shader activeShader, unsigned int count)
    {
        glBindVertexArray(VAO);
        activeShader.use();
        for (size_t i = 0; i < mesh.primitives.size(); ++i)
        {
            tinygltf::Primitive primitive = mesh.primitives[i];
            tinygltf::Accessor indexAccessor = accessors[primitive.indices];

            glActiveTexture(GL_TEXTURE0);
            activeShader.setInt("tex", 0);
            glBindTexture(GL_TEXTURE_2D, texture.id);
            
            glDrawElementsInstanced(primitive.mode, indexAccessor.count, indexAccessor.componentType, BUFFER_OFFSET(indexAccessor.byteOffset), count);
        }
        glBindVertexArray(0);
        glActiveTexture(GL_TEXTURE0);
    }

};


#endif