#pragma once
#ifndef MODELGLTF_H
#define MODELGLTF_H

#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/quaternion.hpp>
#include <glm/gtx/quaternion.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "meshGLTF.h"
#include "tiny_gltf.h"
#include "stb_image.h"
#include "json.hpp"

#include <string>
#include <iostream>
#include <fstream>
#include <map>
#include <vector>

#define BUFFER_OFFSET(i) ((char *)NULL + (i))

class ModelGLTF {
public:
    std::vector<MeshGLTF> meshes;
    tinygltf::Model model;

    ModelGLTF(std::string const& path)
    {
        loadModel(path);
    }

    void Draw(Shader activeShader)
    {

        for (unsigned int i = 0; i < meshes.size(); i++)
        {
            meshes[i].drawMesh(activeShader);
        }
    }

    void DrawInstanced(Shader activeShader, unsigned int count)
    {

        for (unsigned int i = 0; i < meshes.size(); i++)
        {
            meshes[i].drawMeshInstanced(activeShader, count);
        }
    }
private:
    void loadModel(std::string const path)
    {
        tinygltf::TinyGLTF loader;
        std::string err;
        std::string warn;

        bool res = loader.LoadBinaryFromFile(&model, &err, &warn, path);
        if (!warn.empty())
        {
            std::cout << "WARN: " << warn << std::endl;
        }

        if (!err.empty())
        {
            std::cout << "ERR: " << err << std::endl;
        }

        if (!res)
            std::cout << "Failed to load glTF: " << path << std::endl;
        else
            std::cout << "Loaded glTF: " << path << std::endl;
            bindModel();
    }

    void bindModel()
    {
        std::vector<GLuint> VBOs;

        const tinygltf::Scene& scene = model.scenes[model.defaultScene == -1 ? 0 : model.defaultScene];
        for (size_t i = 0; i < scene.nodes.size(); ++i)
        {
            assert((scene.nodes[i] >= 0) && (scene.nodes[i] < model.nodes.size()));
            bindModelNodes(VBOs, model.nodes[scene.nodes[i]]);
        }

        // cleanup vbos
        for (size_t i = 0; i < VBOs.size(); ++i)
        {
            glDeleteBuffers(1, &VBOs[i]);
        }
    }

    void bindModelNodes(std::vector<GLuint> VBOs, tinygltf::Node& node)
    {
        if ((node.mesh >= 0) && (node.mesh < model.meshes.size()))
        {
            //Add a value to bind mesh and to the mesh class
            meshes.push_back(bindMesh(VBOs, model.meshes[node.mesh])); //add instance bool to mesh parsing
            glBindVertexArray(0);
        }

        for (size_t i = 0; i < node.children.size(); i++)
        {
            assert((node.children[i] >= 0) && (node.children[i] < model.nodes.size()));
            bindModelNodes(VBOs, model.nodes[node.children[i]]);
        }
    }

    MeshGLTF bindMesh(std::vector<GLuint> VBOs, tinygltf::Mesh& mesh)
    {
        GLuint VAO;
        glGenVertexArrays(1, &VAO);
        glBindVertexArray(VAO);
        Texture texture;

        for (size_t i = 0; i < mesh.primitives.size(); ++i)
        {
            tinygltf::Primitive primitive = mesh.primitives[i];
            tinygltf::Accessor indexAccessor = model.accessors[primitive.indices];
            tinygltf::Material materialNode = model.materials[primitive.material];
            if (primitive.indices != -1)
            {
                VBOs.push_back(createBuffer(model.bufferViews[indexAccessor.bufferView], GL_ELEMENT_ARRAY_BUFFER));
            }

            for (auto& attrib : primitive.attributes)
            {
                tinygltf::Accessor accessor = model.accessors[attrib.second];

                int vaa = -1;
                if (attrib.first.compare("POSITION") == 0)
                {
                    vaa = 0;
                }
                if (attrib.first.compare("NORMAL") == 0)
                {
                    vaa = 1;
                }
                if (attrib.first.compare("TEXCOORD_0") == 0)
                {
                    vaa = 2;
                }
                if (attrib.first.compare("TANGENT") == 0)
                {
                    vaa = 3;
                }
                if (vaa > -1)
                {
                    VBOs.push_back(bindBuffer(accessor, vaa, GL_ARRAY_BUFFER));
                }
                else
                    std::cout << "vaa missing: " << attrib.first << std::endl;
            }

            if (primitive.material > -1)
            {
                tinygltf::Material mat = model.materials[primitive.material];
                tinygltf::Texture& tex = model.textures[0];
                if (mat.pbrMetallicRoughness.baseColorTexture.index > -1)
                    tex = model.textures[mat.pbrMetallicRoughness.baseColorTexture.index];
                else if (mat.emissiveTexture.index > -1)
                    tex = model.textures[mat.emissiveTexture.index];

                if (tex.source > -1)
                {

                    GLuint texid;
                    glGenTextures(1, &texid);

                    tinygltf::Image& image = model.images[tex.source];

                    glBindTexture(GL_TEXTURE_2D, texid);
                    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
                    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
                    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
                    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
                    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

                    GLenum format = GL_RGBA;

                    if (image.component == 1)
                    {
                        format = GL_RED;
                    }
                    else if (image.component == 2)
                    {
                        format = GL_RG;
                    }
                    else if (image.component == 3)
                    {
                        format = GL_RGB;
                    }

                    GLenum type = GL_UNSIGNED_BYTE;
                    if (image.bits == 8)
                    {
                        // ok
                    }
                    else if (image.bits == 16)
                    {
                        type = GL_UNSIGNED_SHORT;
                    }

                    glTexImage2D(GL_TEXTURE_2D, 0, format, image.width, image.height, 0, format, type, &image.image.at(0));

                    texture.id = texid;
                }
            }
        }

        return MeshGLTF(VAO, mesh, texture,  model.accessors);
    }

    GLuint bindBuffer(tinygltf::Accessor accessor, unsigned int vaa, int targetDefault)
    {
        tinygltf::BufferView bufferView = model.bufferViews[accessor.bufferView];
        GLuint VBO = createBuffer(bufferView, targetDefault);

        int byteStride = accessor.ByteStride(bufferView);
        int size = 1;
        if (accessor.type != TINYGLTF_TYPE_SCALAR)
        {
            size = accessor.type;
        }
        glEnableVertexAttribArray(vaa);
        glVertexAttribPointer(vaa, size, accessor.componentType, accessor.normalized ? GL_TRUE : GL_FALSE, byteStride, BUFFER_OFFSET(accessor.byteOffset));
        glVertexAttribDivisor(vaa, 0);

        return VBO;
    }

    GLuint createBuffer(tinygltf::BufferView bufferView, int targetDefault)
    {
        const tinygltf::Buffer& buffer = model.buffers[bufferView.buffer];
        int target;
        if (bufferView.target == 0)
        {
            target = targetDefault;
        }
        else
        {
            target = bufferView.target;
        }
        std::cout << "bufferview.target " << target << std::endl;


        GLuint VBO;
        glGenBuffers(1, &VBO);
        glBindBuffer(target, VBO);

        std::cout << "buffer.data.size = " << buffer.data.size()
            << ", bufferview.byteOffset = " << bufferView.byteOffset
            << std::endl;

        glBufferData(target, bufferView.byteLength, &buffer.data.at(0) + bufferView.byteOffset, GL_STATIC_DRAW);

        return VBO;
    }
};


#endif