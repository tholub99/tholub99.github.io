#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/quaternion.hpp>
#include <glm/gtx/quaternion.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "tiny_gltf.h"
#include "json.hpp"
#include "camera.h"
#include "shader.h"
#include "modelGLTF.h"

#include <string>
#include <iostream>
#include <fstream>
#include <map>
#include <vector>



void framebuffer_size_callback(GLFWwindow* window, int width, int height);
void mouse_callback(GLFWwindow* window, double xpos, double ypos);
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);
void processInput(GLFWwindow* window);
unsigned int loadTexture(const char* path);
unsigned int loadCubemap(std::vector<std::string> faces);
void setSunShader(Shader shader, glm::mat4 view, glm::mat4 projection, glm::vec3 scale, glm::vec3 position);
void setPlanetShader(Shader shader, glm::mat4 view, glm::mat4 projection, glm::vec3 scale, glm::vec3 orbitCenter,float radius, float speed, float ellipticMod);
void setAsteroidShader(Shader shader, glm::mat4 view, glm::mat4 projection);

// settings
const unsigned int SCR_WIDTH = 1920;
const unsigned int SCR_HEIGHT = 1080;

// camera
Camera camera(glm::vec3(6.0f, 0.0f, 24.0f));
float lastX = (float)SCR_WIDTH / 2.0;
float lastY = (float)SCR_HEIGHT / 2.0;
bool firstMouse = true;

// timing
float deltaTime = 0.0f;
float lastFrame = 0.0f;

int main()
{
    // glfw: initialize and configure
    // ------------------------------
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    glfwWindowHint(GLFW_SAMPLES, 4);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    // glfw window creation
    // --------------------
    GLFWwindow* window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "Project Solar", NULL, NULL);
    if (window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return -1;
    }
    glfwMakeContextCurrent(window);
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
    glfwSetCursorPosCallback(window, mouse_callback);
    glfwSetScrollCallback(window, scroll_callback);

    // tell GLFW to capture our mouse
    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // glad: load all OpenGL function pointers
    // ---------------------------------------
    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
    {
        std::cout << "Failed to initialize GLAD" << std::endl;
        return -1;
    }


    // -----------------------------
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_MULTISAMPLE);
    glEnable(GL_FRAMEBUFFER_SRGB);
    
    Shader sunShader("resources/shaders/gltfShader.vs", "resources/shaders/sunShader.fs");
    Shader skyboxShader("resources/shaders/skyboxShader.vs", "resources/shaders/skyboxShader.fs");
    Shader planetShader("resources/shaders/planetShader.vs", "resources/shaders/planetShader.fs");
    Shader asteroidShader("resources/shaders/instanceAsteroidShader.vs", "resources/shaders/instanceAsteroidShader.fs");

    ModelGLTF Sun("resources/objects/glTF/Sun.glb");
    ModelGLTF Merc("resources/objects/glTF/Mercury.glb");
    ModelGLTF Venus("resources/objects/glTF/Venus.glb");
    ModelGLTF Earth("resources/objects/glTF/Earth.glb");
    ModelGLTF Mars("resources/objects/glTF/Mars.glb");
    ModelGLTF Jupiter("resources/objects/glTF/Jupiter.glb");
    ModelGLTF Saturn("resources/objects/glTF/Saturn.glb");
    ModelGLTF Uranus("resources/objects/glTF/Uranus.glb");
    ModelGLTF Neptune("resources/objects/glTF/Neptune.glb");
    ModelGLTF Pluto("resources/objects/glTF/Pluto.glb");
    ModelGLTF Asteroid("resources/objects/glTF/Bennu_1_1.glb");

    unsigned int amount = 2000;
    glm::mat4* modelMatrices;
    modelMatrices = new glm::mat4[amount];
    srand(glfwGetTime());
    float radius = 25.0f;
    float offset = 3.0f;
    for (unsigned int i = 0; i < amount; i++)
    {
        glm::mat4 instanceModel = glm::mat4(1.0f);
        float angle = (float)i / (float)amount * 360.0f;

        float displacement = (rand() % (int)(2 * offset * 100)) / 100.0f - offset;
        float x = sin(angle) * radius + displacement;
        displacement = (rand() % (int)(2 * offset * 100)) / 100.0f - offset;
        float y = displacement * 0.4f;
        displacement = (rand() % (int)(2 * offset * 100)) / 100.0f - offset;
        float z = cos(angle) * radius + displacement;
        instanceModel = glm::translate(instanceModel, glm::vec3(x, y, z));

        float scale = (rand() % 25) / 1000.0f + 0.005f;
        instanceModel = glm::scale(instanceModel, glm::vec3(scale));

        float rotAngle = (rand() % 360);
        instanceModel = glm::rotate(instanceModel, rotAngle, glm::vec3(0.4f, 0.6f, 0.8f));

        modelMatrices[i] = instanceModel;
    }

    // -------------------------

    // set up vertex data (and buffer(s)) and configure vertex attributes
    // ------------------------------------------------------------------
    float skyboxVertices[] = {
        // positions          
        -1.0f,  1.0f, -1.0f,
        -1.0f, -1.0f, -1.0f,
         1.0f, -1.0f, -1.0f,
         1.0f, -1.0f, -1.0f,
         1.0f,  1.0f, -1.0f,
        -1.0f,  1.0f, -1.0f,

        -1.0f, -1.0f,  1.0f,
        -1.0f, -1.0f, -1.0f,
        -1.0f,  1.0f, -1.0f,
        -1.0f,  1.0f, -1.0f,
        -1.0f,  1.0f,  1.0f,
        -1.0f, -1.0f,  1.0f,

         1.0f, -1.0f, -1.0f,
         1.0f, -1.0f,  1.0f,
         1.0f,  1.0f,  1.0f,
         1.0f,  1.0f,  1.0f,
         1.0f,  1.0f, -1.0f,
         1.0f, -1.0f, -1.0f,

        -1.0f, -1.0f,  1.0f,
        -1.0f,  1.0f,  1.0f,
         1.0f,  1.0f,  1.0f,
         1.0f,  1.0f,  1.0f,
         1.0f, -1.0f,  1.0f,
        -1.0f, -1.0f,  1.0f,

        -1.0f,  1.0f, -1.0f,
         1.0f,  1.0f, -1.0f,
         1.0f,  1.0f,  1.0f,
         1.0f,  1.0f,  1.0f,
        -1.0f,  1.0f,  1.0f,
        -1.0f,  1.0f, -1.0f,

        -1.0f, -1.0f, -1.0f,
        -1.0f, -1.0f,  1.0f,
         1.0f, -1.0f, -1.0f,
         1.0f, -1.0f, -1.0f,
        -1.0f, -1.0f,  1.0f,
         1.0f, -1.0f,  1.0f
    };
    // skybox VAO
    unsigned int skyboxVAO, skyboxVBO;
    glGenVertexArrays(1, &skyboxVAO);
    glGenBuffers(1, &skyboxVBO);
    glBindVertexArray(skyboxVAO);
    glBindBuffer(GL_ARRAY_BUFFER, skyboxVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(skyboxVertices), &skyboxVertices, GL_STATIC_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
    glBindVertexArray(0);

    unsigned int instanceVBO;
    glGenBuffers(1, &instanceVBO);
    glBindBuffer(GL_ARRAY_BUFFER, instanceVBO);
    glBufferData(GL_ARRAY_BUFFER, amount * sizeof(glm::mat4), &modelMatrices[0], GL_STATIC_DRAW);

    for (unsigned int i = 0; i < Asteroid.meshes.size(); i++)
    {
        GLuint VAO = Asteroid.meshes[i].VAO;
        glBindVertexArray(VAO);

        std::size_t vec4Size = sizeof(glm::vec4);
        glEnableVertexAttribArray(3);
        glVertexAttribPointer(3, 4, GL_FLOAT, GL_FALSE, 4 * vec4Size, (void*)0);
        glEnableVertexAttribArray(4);
        glVertexAttribPointer(4, 4, GL_FLOAT, GL_FALSE, 4 * vec4Size, (void*)(1 * vec4Size));
        glEnableVertexAttribArray(5);
        glVertexAttribPointer(5, 4, GL_FLOAT, GL_FALSE, 4 * vec4Size, (void*)(2 * vec4Size));
        glEnableVertexAttribArray(6);
        glVertexAttribPointer(6, 4, GL_FLOAT, GL_FALSE, 4 * vec4Size, (void*)(3 * vec4Size));

        glVertexAttribDivisor(3, 1);
        glVertexAttribDivisor(4, 1);
        glVertexAttribDivisor(5, 1);
        glVertexAttribDivisor(6, 1);

        glBindVertexArray(0);
    }

    // load textures
    // -------------

    std::vector<std::string> faces{
        "resources/textures/starfield/Starfield.png",
        "resources/textures/starfield/Starfield.png",
        "resources/textures/starfield/Starfield.png",
        "resources/textures/starfield/Starfield.png",
        "resources/textures/starfield/Starfield.png",
        "resources/textures/starfield/Starfield.png"
    };


    unsigned int cubemapTexture = loadCubemap(faces);
    // shader configuration
    // --------------------

    skyboxShader.use();
    skyboxShader.setInt("skybox", 0);


    // render loop
    // -----------
    while (!glfwWindowShouldClose(window))
    {
        // per-frame time logic
        // --------------------
        float currentFrame = glfwGetTime();
        deltaTime = currentFrame - lastFrame;
        lastFrame = currentFrame;

        // input
        // -----
        processInput(window);

        // render
        // ------
        glClearColor(0.1f, 0.1f, 0.1f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        // set uniforms
        glm::mat4 view = camera.GetViewMatrix();
        glm::mat4 projection = glm::perspective(glm::radians(camera.Zoom), (float)SCR_WIDTH / (float)SCR_HEIGHT, 0.1f, 1000.0f);
        //Draw Planet(s)
        sunShader.use();
        setSunShader(sunShader, view, projection, glm::vec3(10.0f), glm::vec3(0.0f, 0.0f, 0.0f));
        Sun.Draw(sunShader);
        
        planetShader.use();
        setPlanetShader(planetShader, view, projection, glm::vec3(0.00076f), glm::vec3(-0.1f, 0.0f, 0.1f), 7.0f, 0.3975f, 1.0f);
        Merc.Draw(planetShader);
        
        setPlanetShader(planetShader, view, projection, glm::vec3(0.0019f), glm::vec3(0.01f, 0.0f, -0.01f), 10.0f, 0.2925f, 1.0f);
        Venus.Draw(planetShader);
        
        setPlanetShader(planetShader, view, projection, glm::vec3(0.002f), glm::vec3(0.0f, 0.0f, 0.0f), 14.0f, 0.25f, 1.0f);
        Earth.Draw(planetShader);
        
        setPlanetShader(planetShader, view, projection, glm::vec3(0.001f), glm::vec3(0.15f, 0.0f, -0.15f), 17.0f, 0.20225f, 1.0f);
        Mars.Draw(planetShader);

        setPlanetShader(planetShader, view, projection, glm::vec3(0.022f), glm::vec3(0.0f, 0.0f, 0.0f), 50.0f, 0.11f, 1.0f);
        Jupiter.Draw(planetShader);

        setPlanetShader(planetShader, view, projection, glm::vec3(0.019f), glm::vec3(0.0f, 0.0f, 0.0f), 80.0f, 0.081f, 1.0f);
        Saturn.Draw(planetShader);

        setPlanetShader(planetShader, view, projection, glm::vec3(0.008f), glm::vec3(0.0f, 0.0f, 0.0f), 100.0f, 0.057f, 1.0f);
        Uranus.Draw(planetShader);

        setPlanetShader(planetShader, view, projection, glm::vec3(0.0078f), glm::vec3(0.0f, 0.0f, 0.0f), 110.0f, 0.045f, 1.0f);
        Neptune.Draw(planetShader);

        setPlanetShader(planetShader, view, projection, glm::vec3(0.00037f), glm::vec3(0.0f, 0.0f, 0.0f), 120.0f, 0.039f, 1.0f);
        Pluto.Draw(planetShader);

        asteroidShader.use();
        setAsteroidShader(asteroidShader, view, projection);
        Asteroid.DrawInstanced(asteroidShader, amount);
        //Draw Skybox

        glDepthFunc(GL_LEQUAL);
        skyboxShader.use();
        view = glm::mat4(glm::mat3(camera.GetViewMatrix()));
        skyboxShader.setMat4("view", view);
        skyboxShader.setMat4("projection", projection);

        glBindVertexArray(skyboxVAO);
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_CUBE_MAP, cubemapTexture);
        glDrawArrays(GL_TRIANGLES, 0, 36);

        glBindVertexArray(0);
        glDepthFunc(GL_LESS);

        // glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
        // -------------------------------------------------------------------------------
        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    // optional: de-allocate all resources once they've outlived their purpose:
    // ------------------------------------------------------------------------
    glDeleteVertexArrays(1, &skyboxVAO);
    glDeleteBuffers(1, &skyboxVBO);

    glfwTerminate();
    return 0;
}

// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
// ---------------------------------------------------------------------------------------------------------
void processInput(GLFWwindow* window)
{
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);
    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        camera.ProcessKeyboard(LSHIFT, deltaTime);
    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        camera.ProcessKeyboard(FORWARD, deltaTime);
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        camera.ProcessKeyboard(BACKWARD, deltaTime);
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        camera.ProcessKeyboard(LEFT, deltaTime);
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        camera.ProcessKeyboard(RIGHT, deltaTime);
}

// glfw: whenever the window size changed (by OS or user resize) this callback function executes
// ---------------------------------------------------------------------------------------------
void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
    // make sure the viewport matches the new window dimensions; note that width and 
    // height will be significantly larger than specified on retina displays.
    glViewport(0, 0, width, height);
}

// glfw: whenever the mouse moves, this callback is called
// -------------------------------------------------------
void mouse_callback(GLFWwindow* window, double xpos, double ypos)
{
    if (firstMouse)
    {
        lastX = xpos;
        lastY = ypos;
        firstMouse = false;
    }

    float xoffset = xpos - lastX;
    float yoffset = lastY - ypos; // reversed since y-coordinates go from bottom to top

    lastX = xpos;
    lastY = ypos;

    camera.ProcessMouseMovement(xoffset, yoffset);
}

// glfw: whenever the mouse scroll wheel scrolls, this callback is called
// ----------------------------------------------------------------------
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset)
{
    camera.ProcessMouseScroll(yoffset);
}

// utility function for loading a 2D texture from file
// ---------------------------------------------------
unsigned int loadTexture(char const* path)
{
    unsigned int textureID;
    glGenTextures(1, &textureID);

    int width, height, nrComponents;
    unsigned char* data = stbi_load(path, &width, &height, &nrComponents, 0);
    if (data)
    {
        GLenum format;
        if (nrComponents == 1)
            format = GL_RED;
        else if (nrComponents == 3)
            format = GL_RGB;
        else if (nrComponents == 4)
            format = GL_RGBA;

        glBindTexture(GL_TEXTURE_2D, textureID);
        glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format, GL_UNSIGNED_BYTE, data);
        glGenerateMipmap(GL_TEXTURE_2D);

        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        stbi_image_free(data);
    }
    else
    {
        std::cout << "Texture failed to load at path: " << path << std::endl;
        stbi_image_free(data);
    }

    return textureID;
}

unsigned int loadCubemap(std::vector<std::string> faces)
{
    unsigned int textureID;
    glGenTextures(1, &textureID);
    glBindTexture(GL_TEXTURE_CUBE_MAP, textureID);

    int width, height, nrChannels;
    for (unsigned int i = 0; i < faces.size(); i++)
    {
        unsigned char* data = stbi_load(faces[i].c_str(), &width, &height, &nrChannels, 0);
        if (data)
        {
            glTexImage2D(GL_TEXTURE_CUBE_MAP_POSITIVE_X + i, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);
            stbi_image_free(data);
        }
        else
        {
            std::cout << "Cubemap texture failed to load at path: " << faces[i] << std::endl;
            stbi_image_free(data);
        }
    }
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_R, GL_CLAMP_TO_EDGE);
    glBindTexture(GL_TEXTURE_CUBE_MAP, 0);
    return textureID;
}

void setSunShader(Shader shader, glm::mat4 view, glm::mat4 projection, glm::vec3 scale, glm::vec3 position) {
    glm::mat4 model = glm::mat4(1.0f);
    model = glm::translate(model, position);
    model = glm::rotate(model, (float)glfwGetTime() / 10.0f, glm::vec3(0.0f, 1.0f, 0.0f));
    model = glm::scale(model, scale);

    shader.setMat4("model", model);
    shader.setMat4("view", view);
    shader.setMat4("projection", projection);
}

void setPlanetShader(Shader shader, glm::mat4 view, glm::mat4 projection, glm::vec3 scale, glm::vec3 orbitCenter,float radius, float speed, float ellipticMod) {
    glm::vec3 sun_position = glm::vec3(0.0f, 0.0f, 0.0f);
    glm::vec3 sun_color = glm::vec3(1.0f);
    glm::mat4 model = glm::mat4(1.0f);

    //orbit calculations
    glm::vec3 position = radius * (orbitCenter + glm::vec3(sin(glfwGetTime() * speed), 0.0f, ellipticMod * cos(glfwGetTime() * speed)));
    model = glm::translate(model, position);
    model = glm::rotate(model, (float)glfwGetTime() / 2.0f, glm::vec3(0.0f, 1.0f, 0.0f));
    model = glm::scale(model, scale);
    shader.setVec3("light.ambient", 0.05f, 0.05f, 0.05f);
    shader.setVec3("light.diffuse", 1.5f, 1.5f, 1.5f);
    shader.setVec3("light.specular", 0.1f, 0.1f, 0.1f);
    shader.setVec3("view_position", camera.Position);
    shader.setMat4("model", model);
    shader.setMat4("view", view);
    shader.setMat4("projection", projection);
    shader.setVec3("sun_position", sun_position);
    shader.setVec3("sun_color", sun_color);
}

void setAsteroidShader(Shader shader, glm::mat4 view, glm::mat4 projection)
{
    float radius = 20.0f;
    glm::vec3 sun_position = glm::vec3(0.0f, 0.0f, 0.0f);
    glm::vec3 sun_color = glm::vec3(1.0f);

    shader.setVec3("light.ambient", 0.05f, 0.05f, 0.05f);
    shader.setVec3("light.diffuse", 1.5f, 1.5f, 1.5f);
    shader.setVec3("light.specular", 0.1f, 0.1f, 0.1f);
    shader.setVec3("view_position", camera.Position);
    shader.setMat4("view", view);
    shader.setMat4("projection", projection);
    shader.setVec3("sun_position", sun_position);
    shader.setVec3("sun_color", sun_color);
}